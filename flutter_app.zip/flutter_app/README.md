# 📱 قاعدة بيانات الطلاب - Student Database

تطبيق Android للبحث عن الطلاب وإدارة السجلات النفسية والسلوكية.
**يعمل Offline بالكامل بدون إنترنت.**

---

## ✨ المميزات

- 📥 **استيراد CSV**: استيراد بيانات الطلاب من ملف CSV
- 🔍 **بحث ذكي**: بحث بالاسم (جزئي) أو الرقم المدرسي مع تطبيع عربي
- 👤 **تفاصيل الطالب**: عرض كامل بيانات الطالب
- 🔐 **وحدة الحالات**: سجلات المشكلات النفسية والسلوكية (محمية برمز)
- 📤 **تصدير JSON**: تصدير سجل الطالب الكامل

---

## 📁 هيكل المشروع

```
lib/
├── main.dart                    # نقطة البداية
├── models/
│   ├── student.dart            # نموذج الطالب
│   └── case_record.dart        # نموذج سجل الحالة
├── services/
│   ├── database_service.dart   # خدمة SQLite
│   ├── csv_import_service.dart # خدمة استيراد CSV
│   ├── export_service.dart     # خدمة التصدير
│   └── arabic_normalizer.dart  # تطبيع النص العربي
└── screens/
    ├── search_screen.dart      # شاشة البحث
    ├── import_screen.dart      # شاشة الاستيراد
    ├── student_detail_screen.dart # تفاصيل الطالب
    └── case_records_screen.dart   # سجلات الحالات
```

---

## 🛠️ بناء APK

### الطريقة 1: Android Studio (على الكمبيوتر)

1. ثبّت [Flutter SDK](https://flutter.dev/docs/get-started/install)
2. ثبّت [Android Studio](https://developer.android.com/studio)
3. افتح المشروع في Android Studio
4. شغّل:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
5. الملف في: `build/app/outputs/flutter-apk/app-release.apk`

### الطريقة 2: GitHub Actions (بدون كمبيوتر) ⭐

1. أنشئ حساب GitHub (من الجوال)
2. أنشئ Repository جديد
3. ارفع ملفات المشروع
4. اذهب لـ **Actions** → **Build Android APK** → **Run workflow**
5. انتظر 5-10 دقائق
6. حمّل APK من **Artifacts**

---

## 📋 متطلبات ملف CSV

يجب أن يحتوي على الأعمدة التالية (أو بدائلها):

| العمود المطلوب | البدائل المقبولة |
|---------------|-----------------|
| الاسم | الاسم الكامل، اسم الطالب |
| الرقم المدرسي | رقم الطالب، الرقم |
| الصف | المرحلة |
| الشعبة | الفصل |
| الجنسية | - |
| حالة القيد | الحالة |
| الهاتف | رقم الهاتف، الجوال |
| المنطقة | العنوان، السكن |

---

## 🔐 رمز وحدة الحالات

الرمز الافتراضي: **`2005`**

---

## 📄 الترخيص

MIT License
