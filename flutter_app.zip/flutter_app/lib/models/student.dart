/// نموذج بيانات الطالب
class Student {
  final int? id;
  final String name;
  final String schoolId;
  final String grade;
  final String section;
  final String nationality;
  final String status;
  final String? phone;
  final String? area;
  final String? extraData; // بيانات إضافية بصيغة JSON

  Student({
    this.id,
    required this.name,
    required this.schoolId,
    required this.grade,
    this.section = '',
    this.nationality = '',
    this.status = '',
    this.phone,
    this.area,
    this.extraData,
  });

  /// تحويل من Map (من قاعدة البيانات)
  factory Student.fromMap(Map<String, dynamic> map) {
    return Student(
      id: map['id'] as int?,
      name: map['name'] as String? ?? '',
      schoolId: map['school_id'] as String? ?? '',
      grade: map['grade'] as String? ?? '',
      section: map['section'] as String? ?? '',
      nationality: map['nationality'] as String? ?? '',
      status: map['status'] as String? ?? '',
      phone: map['phone'] as String?,
      area: map['area'] as String?,
      extraData: map['extra_data'] as String?,
    );
  }

  /// تحويل إلى Map (لقاعدة البيانات)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'school_id': schoolId,
      'grade': grade,
      'section': section,
      'nationality': nationality,
      'status': status,
      'phone': phone,
      'area': area,
      'extra_data': extraData,
    };
  }

  /// الصف والشعبة معاً
  String get gradeWithSection {
    if (section.isNotEmpty) {
      return '$grade / $section';
    }
    return grade;
  }

  /// نسخة معدّلة
  Student copyWith({
    int? id,
    String? name,
    String? schoolId,
    String? grade,
    String? section,
    String? nationality,
    String? status,
    String? phone,
    String? area,
    String? extraData,
  }) {
    return Student(
      id: id ?? this.id,
      name: name ?? this.name,
      schoolId: schoolId ?? this.schoolId,
      grade: grade ?? this.grade,
      section: section ?? this.section,
      nationality: nationality ?? this.nationality,
      status: status ?? this.status,
      phone: phone ?? this.phone,
      area: area ?? this.area,
      extraData: extraData ?? this.extraData,
    );
  }
}
