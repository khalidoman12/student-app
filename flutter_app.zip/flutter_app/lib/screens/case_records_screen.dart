import 'package:flutter/material.dart';
import '../models/student.dart';
import '../models/case_record.dart';
import '../services/database_service.dart';

/// شاشة سجلات المشكلات النفسية والسلوكية
class CaseRecordsScreen extends StatefulWidget {
  final Student student;

  const CaseRecordsScreen({super.key, required this.student});

  @override
  State<CaseRecordsScreen> createState() => _CaseRecordsScreenState();
}

class _CaseRecordsScreenState extends State<CaseRecordsScreen> {
  List<CaseRecord> _records = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRecords();
  }

  Future<void> _loadRecords() async {
    setState(() => _isLoading = true);
    
    final records = await DatabaseService.getCaseRecords(widget.student.schoolId);
    
    setState(() {
      _records = records;
      _isLoading = false;
    });
  }

  void _addNewRecord() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddCaseRecordScreen(student: widget.student),
      ),
    ).then((_) => _loadRecords());
  }

  Future<void> _deleteRecord(CaseRecord record) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: const Text('هل أنت متأكد من حذف هذا السجل؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('حذف'),
          ),
        ],
      ),
    );

    if (confirm == true && record.id != null) {
      await DatabaseService.deleteCaseRecord(record.id!);
      _loadRecords();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('سجل الحالات'),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // معلومات الطالب
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: Colors.deepPurple.withOpacity(0.1),
            child: Column(
              children: [
                Text(
                  widget.student.name,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  '${widget.student.schoolId} • ${widget.student.gradeWithSection}',
                  style: const TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ),

          // القائمة
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _records.isEmpty
                    ? _buildEmptyState()
                    : _buildRecordsList(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addNewRecord,
        icon: const Icon(Icons.add),
        label: const Text('إضافة سجل'),
        backgroundColor: Colors.deepPurple,
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.folder_open,
            size: 80,
            color: Colors.grey.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          const Text(
            'لا توجد سجلات',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'اضغط على + لإضافة سجل جديد',
            style: TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildRecordsList() {
    return ListView.builder(
      itemCount: _records.length,
      padding: const EdgeInsets.all(12),
      itemBuilder: (context, index) {
        final record = _records[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ExpansionTile(
            leading: CircleAvatar(
              backgroundColor: _getProblemColor(record.problemType),
              child: const Icon(Icons.description, color: Colors.white, size: 20),
            ),
            title: Text(
              record.problemType,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(record.formattedDate),
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildDetailRow('الوصف', record.description),
                    if (record.notes.isNotEmpty)
                      _buildDetailRow('ملاحظات', record.notes),
                    if (record.referralSource.isNotEmpty)
                      _buildDetailRow('مصدر الإحالة', record.referralSource),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton.icon(
                          onPressed: () => _deleteRecord(record),
                          icon: const Icon(Icons.delete, size: 18),
                          label: const Text('حذف'),
                          style: TextButton.styleFrom(foregroundColor: Colors.red),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              '$label:',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey,
              ),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  Color _getProblemColor(String type) {
    switch (type) {
      case 'مشكلة سلوكية':
        return Colors.orange;
      case 'مشكلة نفسية':
        return Colors.purple;
      case 'صعوبات تعلم':
        return Colors.blue;
      case 'تنمر':
        return Colors.red;
      case 'قلق وتوتر':
        return Colors.amber;
      default:
        return Colors.grey;
    }
  }
}

/// شاشة إضافة سجل جديد
class AddCaseRecordScreen extends StatefulWidget {
  final Student student;

  const AddCaseRecordScreen({super.key, required this.student});

  @override
  State<AddCaseRecordScreen> createState() => _AddCaseRecordScreenState();
}

class _AddCaseRecordScreenState extends State<AddCaseRecordScreen> {
  final _formKey = GlobalKey<FormState>();
  DateTime _selectedDate = DateTime.now();
  String? _selectedProblemType;
  String? _selectedReferralSource;
  final _descriptionController = TextEditingController();
  final _notesController = TextEditingController();
  bool _isSaving = false;

  Future<void> _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _saveRecord() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedProblemType == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اختر نوع المشكلة')),
      );
      return;
    }

    setState(() => _isSaving = true);

    final record = CaseRecord(
      studentSchoolId: widget.student.schoolId,
      date: _selectedDate,
      problemType: _selectedProblemType!,
      description: _descriptionController.text.trim(),
      notes: _notesController.text.trim(),
      referralSource: _selectedReferralSource ?? '',
    );

    await DatabaseService.insertCaseRecord(record);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم حفظ السجل بنجاح'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة سجل جديد'),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // التاريخ
              Card(
                child: ListTile(
                  leading: const Icon(Icons.calendar_today),
                  title: const Text('التاريخ'),
                  subtitle: Text(
                    '${_selectedDate.year}/${_selectedDate.month}/${_selectedDate.day}',
                  ),
                  trailing: const Icon(Icons.edit),
                  onTap: _selectDate,
                ),
              ),

              const SizedBox(height: 16),

              // نوع المشكلة
              DropdownButtonFormField<String>(
                value: _selectedProblemType,
                decoration: const InputDecoration(
                  labelText: 'نوع المشكلة *',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.category),
                ),
                items: ProblemTypes.types.map((type) {
                  return DropdownMenuItem(value: type, child: Text(type));
                }).toList(),
                onChanged: (value) => setState(() => _selectedProblemType = value),
              ),

              const SizedBox(height: 16),

              // الوصف
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'وصف المشكلة *',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.description),
                  alignLabelWithHint: true,
                ),
                maxLines: 4,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'الوصف مطلوب';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 16),

              // مصدر الإحالة
              DropdownButtonFormField<String>(
                value: _selectedReferralSource,
                decoration: const InputDecoration(
                  labelText: 'مصدر الإحالة',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
                items: ReferralSources.sources.map((source) {
                  return DropdownMenuItem(value: source, child: Text(source));
                }).toList(),
                onChanged: (value) => setState(() => _selectedReferralSource = value),
              ),

              const SizedBox(height: 16),

              // ملاحظات
              TextFormField(
                controller: _notesController,
                decoration: const InputDecoration(
                  labelText: 'ملاحظات إضافية',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.note),
                  alignLabelWithHint: true,
                ),
                maxLines: 3,
              ),

              const SizedBox(height: 24),

              // زر الحفظ
              ElevatedButton.icon(
                onPressed: _isSaving ? null : _saveRecord,
                icon: _isSaving
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.save),
                label: Text(_isSaving ? 'جاري الحفظ...' : 'حفظ السجل'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.all(16),
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    _notesController.dispose();
    super.dispose();
  }
}
