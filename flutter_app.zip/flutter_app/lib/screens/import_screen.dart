import 'package:flutter/material.dart';
import '../services/csv_import_service.dart';
import '../services/database_service.dart';

/// شاشة استيراد ملف CSV
class ImportScreen extends StatefulWidget {
  const ImportScreen({super.key});

  @override
  State<ImportScreen> createState() => _ImportScreenState();
}

class _ImportScreenState extends State<ImportScreen> {
  bool _isLoading = false;
  int _studentsCount = 0;
  String? _lastImportMessage;
  bool _lastImportSuccess = false;

  @override
  void initState() {
    super.initState();
    _loadStudentsCount();
  }

  Future<void> _loadStudentsCount() async {
    final count = await DatabaseService.getStudentsCount();
    setState(() {
      _studentsCount = count;
    });
  }

  Future<void> _pickAndImport({bool replace = false}) async {
    setState(() {
      _isLoading = true;
      _lastImportMessage = null;
    });

    try {
      // اختيار الملف
      final result = await CsvImportService.pickCsvFile();
      
      if (result == null || result.files.isEmpty) {
        setState(() {
          _isLoading = false;
          _lastImportMessage = 'لم يتم اختيار ملف';
          _lastImportSuccess = false;
        });
        return;
      }

      final filePath = result.files.first.path;
      if (filePath == null) {
        setState(() {
          _isLoading = false;
          _lastImportMessage = 'خطأ في مسار الملف';
          _lastImportSuccess = false;
        });
        return;
      }

      // استيراد البيانات
      final importResult = await CsvImportService.importFromFile(
        filePath,
        replace: replace,
      );

      await _loadStudentsCount();

      setState(() {
        _isLoading = false;
        if (importResult.success) {
          _lastImportMessage = 'تم استيراد ${importResult.importedCount} طالب بنجاح';
          _lastImportSuccess = true;
        } else {
          _lastImportMessage = importResult.errorMessage ?? 'خطأ غير معروف';
          _lastImportSuccess = false;
        }
      });

    } catch (e) {
      setState(() {
        _isLoading = false;
        _lastImportMessage = 'خطأ: $e';
        _lastImportSuccess = false;
      });
    }
  }

  Future<void> _confirmReimport() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تأكيد إعادة الاستيراد'),
        content: const Text(
          'سيتم حذف جميع بيانات الطلاب الحالية واستبدالها بالبيانات الجديدة.\n\n'
          'ملاحظة: سجلات الحالات لن تُحذف.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
            ),
            child: const Text('متابعة'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _pickAndImport(replace: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('استيراد البيانات'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // بطاقة الإحصائيات
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Icon(
                      Icons.people,
                      size: 48,
                      color: Colors.blue,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '$_studentsCount',
                      style: const TextStyle(
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Text(
                      'طالب في قاعدة البيانات',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 30),

            // زر استيراد جديد
            ElevatedButton.icon(
              onPressed: _isLoading ? null : () => _pickAndImport(replace: false),
              icon: const Icon(Icons.file_upload),
              label: const Text('استيراد ملف CSV'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.all(16),
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
              ),
            ),

            const SizedBox(height: 15),

            // زر إعادة الاستيراد
            OutlinedButton.icon(
              onPressed: _isLoading ? null : _confirmReimport,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة استيراد (استبدال الكل)'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.all(16),
                foregroundColor: Colors.orange,
              ),
            ),

            const SizedBox(height: 30),

            // حالة التحميل
            if (_isLoading)
              const Center(
                child: Column(
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 10),
                    Text('جاري الاستيراد...'),
                  ],
                ),
              ),

            // رسالة النتيجة
            if (_lastImportMessage != null && !_isLoading)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _lastImportSuccess
                      ? Colors.green.withOpacity(0.1)
                      : Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _lastImportSuccess ? Colors.green : Colors.red,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _lastImportSuccess ? Icons.check_circle : Icons.error,
                      color: _lastImportSuccess ? Colors.green : Colors.red,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _lastImportMessage!,
                        style: TextStyle(
                          color: _lastImportSuccess ? Colors.green : Colors.red,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            const Spacer(),

            // تعليمات
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '💡 تعليمات:',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text('• الملف يجب أن يكون بصيغة CSV'),
                  Text('• يجب أن يحتوي على عمود "الاسم" و "الرقم المدرسي"'),
                  Text('• الأعمدة الإضافية سيتم حفظها تلقائياً'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
