import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/student.dart';
import '../models/case_record.dart';
import 'arabic_normalizer.dart';

/// خدمة قاعدة البيانات SQLite
class DatabaseService {
  static Database? _database;
  static const String _dbName = 'students_database.db';
  static const int _dbVersion = 1;

  /// الحصول على قاعدة البيانات
  static Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  /// تهيئة قاعدة البيانات
  static Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, _dbName);

    return await openDatabase(
      path,
      version: _dbVersion,
      onCreate: _onCreate,
    );
  }

  /// إنشاء الجداول
  static Future<void> _onCreate(Database db, int version) async {
    // جدول الطلاب
    await db.execute('''
      CREATE TABLE students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        name_normalized TEXT NOT NULL,
        school_id TEXT UNIQUE NOT NULL,
        grade TEXT,
        section TEXT,
        nationality TEXT,
        status TEXT,
        phone TEXT,
        area TEXT,
        extra_data TEXT
      )
    ''');

    // جدول سجلات الحالات
    await db.execute('''
      CREATE TABLE case_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_school_id TEXT NOT NULL,
        date TEXT NOT NULL,
        problem_type TEXT NOT NULL,
        description TEXT,
        notes TEXT,
        referral_source TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (student_school_id) REFERENCES students (school_id)
      )
    ''');

    // فهرس للبحث السريع
    await db.execute('CREATE INDEX idx_name_normalized ON students (name_normalized)');
    await db.execute('CREATE INDEX idx_school_id ON students (school_id)');
    await db.execute('CREATE INDEX idx_case_student ON case_records (student_school_id)');
  }

  // ==================== عمليات الطلاب ====================

  /// إضافة طالب واحد
  static Future<int> insertStudent(Student student) async {
    final db = await database;
    final map = student.toMap();
    map['name_normalized'] = ArabicNormalizer.normalize(student.name);
    map.remove('id');
    
    return await db.insert(
      'students',
      map,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// إضافة قائمة طلاب (استيراد)
  static Future<int> importStudents(List<Student> students, {bool replace = false}) async {
    final db = await database;
    int count = 0;

    if (replace) {
      await db.delete('students');
    }

    final batch = db.batch();
    for (final student in students) {
      final map = student.toMap();
      map['name_normalized'] = ArabicNormalizer.normalize(student.name);
      map.remove('id');
      
      batch.insert(
        'students',
        map,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      count++;
    }

    await batch.commit(noResult: true);
    return count;
  }

  /// البحث عن طلاب
  static Future<List<Student>> searchStudents(String query) async {
    final db = await database;
    
    if (query.isEmpty) {
      return [];
    }

    // البحث بالرقم المدرسي أولاً (مطابقة تامة)
    final byId = await db.query(
      'students',
      where: 'school_id = ?',
      whereArgs: [query],
    );

    if (byId.isNotEmpty) {
      return byId.map((map) => Student.fromMap(map)).toList();
    }

    // البحث بالاسم (مطابقة جزئية مع تطبيع)
    final normalizedQuery = ArabicNormalizer.normalize(query);
    final byName = await db.query(
      'students',
      where: 'name_normalized LIKE ?',
      whereArgs: ['%$normalizedQuery%'],
      orderBy: 'name',
    );

    return byName.map((map) => Student.fromMap(map)).toList();
  }

  /// الحصول على طالب بالرقم المدرسي
  static Future<Student?> getStudentBySchoolId(String schoolId) async {
    final db = await database;
    final result = await db.query(
      'students',
      where: 'school_id = ?',
      whereArgs: [schoolId],
    );

    if (result.isEmpty) return null;
    return Student.fromMap(result.first);
  }

  /// الحصول على عدد الطلاب
  static Future<int> getStudentsCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM students');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  /// الحصول على جميع الطلاب
  static Future<List<Student>> getAllStudents() async {
    final db = await database;
    final result = await db.query('students', orderBy: 'name');
    return result.map((map) => Student.fromMap(map)).toList();
  }

  /// حذف جميع الطلاب
  static Future<void> deleteAllStudents() async {
    final db = await database;
    await db.delete('students');
  }

  // ==================== عمليات سجلات الحالات ====================

  /// إضافة سجل حالة
  static Future<int> insertCaseRecord(CaseRecord record) async {
    final db = await database;
    final map = record.toMap();
    map.remove('id');
    
    return await db.insert('case_records', map);
  }

  /// الحصول على سجلات طالب
  static Future<List<CaseRecord>> getCaseRecords(String studentSchoolId) async {
    final db = await database;
    final result = await db.query(
      'case_records',
      where: 'student_school_id = ?',
      whereArgs: [studentSchoolId],
      orderBy: 'date DESC',
    );

    return result.map((map) => CaseRecord.fromMap(map)).toList();
  }

  /// حذف سجل حالة
  static Future<void> deleteCaseRecord(int id) async {
    final db = await database;
    await db.delete(
      'case_records',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// تحديث سجل حالة
  static Future<void> updateCaseRecord(CaseRecord record) async {
    final db = await database;
    await db.update(
      'case_records',
      record.toMap(),
      where: 'id = ?',
      whereArgs: [record.id],
    );
  }

  // ==================== عمليات عامة ====================

  /// إغلاق قاعدة البيانات
  static Future<void> close() async {
    final db = await database;
    await db.close();
    _database = null;
  }

  /// إعادة تعيين قاعدة البيانات
  static Future<void> resetDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, _dbName);
    
    await close();
    await deleteDatabase(path);
    _database = await _initDatabase();
  }
}
