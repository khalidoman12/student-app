/// نموذج سجل المشكلات النفسية والسلوكية
class CaseRecord {
  final int? id;
  final String studentSchoolId;
  final DateTime date;
  final String problemType;
  final String description;
  final String notes;
  final String referralSource;
  final DateTime createdAt;

  CaseRecord({
    this.id,
    required this.studentSchoolId,
    required this.date,
    required this.problemType,
    required this.description,
    this.notes = '',
    this.referralSource = '',
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  /// تحويل من Map
  factory CaseRecord.fromMap(Map<String, dynamic> map) {
    return CaseRecord(
      id: map['id'] as int?,
      studentSchoolId: map['student_school_id'] as String? ?? '',
      date: DateTime.tryParse(map['date'] as String? ?? '') ?? DateTime.now(),
      problemType: map['problem_type'] as String? ?? '',
      description: map['description'] as String? ?? '',
      notes: map['notes'] as String? ?? '',
      referralSource: map['referral_source'] as String? ?? '',
      createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ?? DateTime.now(),
    );
  }

  /// تحويل إلى Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'student_school_id': studentSchoolId,
      'date': date.toIso8601String().split('T')[0],
      'problem_type': problemType,
      'description': description,
      'notes': notes,
      'referral_source': referralSource,
      'created_at': createdAt.toIso8601String(),
    };
  }

  /// تحويل إلى JSON للتصدير
  Map<String, dynamic> toJson() {
    return {
      'التاريخ': date.toIso8601String().split('T')[0],
      'نوع_المشكلة': problemType,
      'الوصف': description,
      'ملاحظات': notes,
      'مصدر_الإحالة': referralSource,
      'تاريخ_الإنشاء': createdAt.toIso8601String(),
    };
  }

  /// التاريخ بصيغة مقروءة
  String get formattedDate {
    return '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}';
  }
}

/// أنواع المشكلات المتاحة
class ProblemTypes {
  static const List<String> types = [
    'مشكلة سلوكية',
    'مشكلة نفسية',
    'صعوبات تعلم',
    'مشكلة اجتماعية',
    'تنمر',
    'قلق وتوتر',
    'اكتئاب',
    'فرط حركة',
    'تشتت انتباه',
    'عدوانية',
    'انسحاب اجتماعي',
    'مشكلة أسرية',
    'أخرى',
  ];
}

/// مصادر الإحالة
class ReferralSources {
  static const List<String> sources = [
    'المعلم',
    'ولي الأمر',
    'الإدارة',
    'الطالب نفسه',
    'زميل',
    'المرشد الطلابي',
    'ملاحظة ذاتية',
    'أخرى',
  ];
}
