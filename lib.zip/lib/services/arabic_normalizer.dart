/// خدمة تطبيع النص العربي للبحث الذكي
class ArabicNormalizer {
  /// تطبيع النص العربي
  static String normalize(String text) {
    if (text.isEmpty) return '';

    String normalized = text;

    // إزالة التشكيل
    normalized = _removeDiacritics(normalized);

    // توحيد الألف
    normalized = normalized
        .replaceAll('أ', 'ا')
        .replaceAll('إ', 'ا')
        .replaceAll('آ', 'ا')
        .replaceAll('ٱ', 'ا');

    // توحيد الياء والألف المقصورة
    normalized = normalized
        .replaceAll('ى', 'ي')
        .replaceAll('ئ', 'ي');

    // توحيد التاء المربوطة
    normalized = normalized.replaceAll('ة', 'ه');

    // توحيد الواو
    normalized = normalized.replaceAll('ؤ', 'و');

    // إزالة المسافات الزائدة
    normalized = normalized.replaceAll(RegExp(r'\s+'), ' ').trim();

    return normalized;
  }

  /// إزالة التشكيل من النص
  static String _removeDiacritics(String text) {
    // التشكيلات العربية
    const diacritics = [
      '\u064B', // فتحتان
      '\u064C', // ضمتان
      '\u064D', // كسرتان
      '\u064E', // فتحة
      '\u064F', // ضمة
      '\u0650', // كسرة
      '\u0651', // شدة
      '\u0652', // سكون
      '\u0653', // مدة
      '\u0654', // همزة فوقية
      '\u0655', // همزة تحتية
      '\u0656', // subscript alef
      '\u0657', // inverted damma
      '\u0658', // mark noon ghunna
      '\u0659', // zwarakay
      '\u065A', // vowel sign small v above
      '\u065B', // vowel sign inverted small v above
      '\u065C', // vowel sign dot below
      '\u065D', // reversed damma
      '\u065E', // fatha with two dots
      '\u065F', // wavy hamza below
      '\u0670', // superscript alef
    ];

    String result = text;
    for (final diacritic in diacritics) {
      result = result.replaceAll(diacritic, '');
    }
    return result;
  }

  /// البحث مع التطبيع
  static bool matchesSearch(String text, String query) {
    if (query.isEmpty) return true;
    
    final normalizedText = normalize(text.toLowerCase());
    final normalizedQuery = normalize(query.toLowerCase());
    
    return normalizedText.contains(normalizedQuery);
  }
}
