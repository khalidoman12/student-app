import 'dart:io';
import 'package:csv/csv.dart';
import 'package:file_picker/file_picker.dart';
import '../models/student.dart';
import 'database_service.dart';

/// خدمة استيراد ملفات CSV
class CsvImportService {
  /// الأعمدة المتوقعة وبدائلها
  static const Map<String, List<String>> columnMappings = {
    'name': ['الاسم', 'الاسم الكامل', 'اسم الطالب', 'الاسم الرباعي', 'name'],
    'school_id': ['الرقم المدرسي', 'رقم الطالب', 'الرقم', 'school_id', 'id'],
    'grade': ['الصف', 'المرحلة', 'grade', 'class'],
    'section': ['الشعبة', 'الفصل', 'section', 'division'],
    'nationality': ['الجنسية', 'nationality'],
    'status': ['حالة القيد', 'الحالة', 'status'],
    'phone': ['الهاتف', 'رقم الهاتف', 'الجوال', 'phone', 'mobile'],
    'area': ['المنطقة', 'العنوان', 'السكن', 'area', 'address'],
  };

  /// اختيار ملف CSV
  static Future<FilePickerResult?> pickCsvFile() async {
    return await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv', 'CSV'],
      allowMultiple: false,
    );
  }

  /// قراءة وتحليل ملف CSV
  static Future<ImportResult> importFromFile(String filePath, {bool replace = false}) async {
    try {
      final file = File(filePath);
      
      if (!await file.exists()) {
        return ImportResult.error('الملف غير موجود');
      }

      // قراءة الملف بترميزات مختلفة
      String content;
      try {
        content = await file.readAsString();
      } catch (e) {
        // محاولة قراءة بترميز آخر
        final bytes = await file.readAsBytes();
        content = String.fromCharCodes(bytes);
      }

      // تحليل CSV
      final List<List<dynamic>> rows = const CsvToListConverter(
        eol: '\n',
        shouldParseNumbers: false,
      ).convert(content);

      if (rows.isEmpty) {
        return ImportResult.error('الملف فارغ');
      }

      // الحصول على رؤوس الأعمدة
      final headers = rows.first.map((e) => e.toString().trim()).toList();
      
      // إنشاء خريطة الأعمدة
      final columnIndexMap = _mapColumns(headers);
      
      if (columnIndexMap['name'] == null || columnIndexMap['school_id'] == null) {
        return ImportResult.error(
          'الملف لا يحتوي على الأعمدة المطلوبة (الاسم والرقم المدرسي)'
        );
      }

      // تحويل الصفوف إلى طلاب
      final students = <Student>[];
      final errors = <String>[];

      for (int i = 1; i < rows.length; i++) {
        final row = rows[i];
        
        try {
          final student = _rowToStudent(row, columnIndexMap, headers);
          if (student != null && student.name.isNotEmpty && student.schoolId.isNotEmpty) {
            students.add(student);
          }
        } catch (e) {
          errors.add('خطأ في الصف ${i + 1}: $e');
        }
      }

      if (students.isEmpty) {
        return ImportResult.error('لم يتم العثور على بيانات صالحة');
      }

      // حفظ في قاعدة البيانات
      final importedCount = await DatabaseService.importStudents(
        students,
        replace: replace,
      );

      return ImportResult.success(
        importedCount: importedCount,
        totalRows: rows.length - 1,
        errors: errors,
      );

    } catch (e) {
      return ImportResult.error('خطأ في قراءة الملف: $e');
    }
  }

  /// إنشاء خريطة الأعمدة
  static Map<String, int?> _mapColumns(List<String> headers) {
    final Map<String, int?> result = {};

    for (final entry in columnMappings.entries) {
      final fieldName = entry.key;
      final possibleNames = entry.value;

      for (int i = 0; i < headers.length; i++) {
        final header = headers[i].trim();
        if (possibleNames.any((name) => 
            header == name || 
            header.contains(name) ||
            name.contains(header))) {
          result[fieldName] = i;
          break;
        }
      }
    }

    return result;
  }

  /// تحويل صف إلى طالب
  static Student? _rowToStudent(
    List<dynamic> row,
    Map<String, int?> columnMap,
    List<String> headers,
  ) {
    String getValue(String field) {
      final index = columnMap[field];
      if (index == null || index >= row.length) return '';
      return row[index]?.toString().trim() ?? '';
    }

    final name = getValue('name');
    final schoolId = getValue('school_id');

    if (name.isEmpty || schoolId.isEmpty) return null;

    // جمع البيانات الإضافية
    final extraData = <String, String>{};
    for (int i = 0; i < headers.length; i++) {
      if (!columnMap.values.contains(i) && i < row.length) {
        final value = row[i]?.toString().trim() ?? '';
        if (value.isNotEmpty) {
          extraData[headers[i]] = value;
        }
      }
    }

    return Student(
      name: name,
      schoolId: schoolId,
      grade: getValue('grade'),
      section: getValue('section'),
      nationality: getValue('nationality'),
      status: getValue('status'),
      phone: getValue('phone'),
      area: getValue('area'),
      extraData: extraData.isNotEmpty ? extraData.toString() : null,
    );
  }
}

/// نتيجة الاستيراد
class ImportResult {
  final bool success;
  final int importedCount;
  final int totalRows;
  final String? errorMessage;
  final List<String> errors;

  ImportResult._({
    required this.success,
    this.importedCount = 0,
    this.totalRows = 0,
    this.errorMessage,
    this.errors = const [],
  });

  factory ImportResult.success({
    required int importedCount,
    required int totalRows,
    List<String> errors = const [],
  }) {
    return ImportResult._(
      success: true,
      importedCount: importedCount,
      totalRows: totalRows,
      errors: errors,
    );
  }

  factory ImportResult.error(String message) {
    return ImportResult._(
      success: false,
      errorMessage: message,
    );
  }
}
