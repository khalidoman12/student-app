import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/student.dart';
import '../models/case_record.dart';
import 'database_service.dart';

/// خدمة تصدير البيانات
class ExportService {
  /// تصدير سجل طالب كامل إلى JSON
  static Future<ExportResult> exportStudentRecord(Student student) async {
    try {
      // الحصول على سجلات الحالات
      final caseRecords = await DatabaseService.getCaseRecords(student.schoolId);

      // إنشاء البيانات
      final data = {
        'معلومات_الطالب': {
          'الاسم': student.name,
          'الرقم_المدرسي': student.schoolId,
          'الصف': student.grade,
          'الشعبة': student.section,
          'الجنسية': student.nationality,
          'حالة_القيد': student.status,
          'الهاتف': student.phone ?? '',
          'المنطقة': student.area ?? '',
        },
        'سجلات_الحالات': caseRecords.map((r) => r.toJson()).toList(),
        'تاريخ_التصدير': DateTime.now().toIso8601String(),
        'عدد_السجلات': caseRecords.length,
      };

      // إنشاء الملف
      final directory = await getExternalStorageDirectory() ?? 
                        await getApplicationDocumentsDirectory();
      
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = 'student_${student.schoolId}_$timestamp.json';
      final filePath = '${directory.path}/$fileName';

      final file = File(filePath);
      await file.writeAsString(
        const JsonEncoder.withIndent('  ').convert(data),
        encoding: utf8,
      );

      return ExportResult.success(filePath);

    } catch (e) {
      return ExportResult.error('فشل التصدير: $e');
    }
  }

  /// تصدير جميع الطلاب إلى JSON
  static Future<ExportResult> exportAllStudents() async {
    try {
      final students = await DatabaseService.getAllStudents();

      if (students.isEmpty) {
        return ExportResult.error('لا يوجد طلاب للتصدير');
      }

      final data = {
        'الطلاب': students.map((s) => {
          return {
            'الاسم': s.name,
            'الرقم_المدرسي': s.schoolId,
            'الصف': s.grade,
            'الشعبة': s.section,
            'الجنسية': s.nationality,
            'حالة_القيد': s.status,
            'الهاتف': s.phone ?? '',
            'المنطقة': s.area ?? '',
          };
        }).toList(),
        'تاريخ_التصدير': DateTime.now().toIso8601String(),
        'عدد_الطلاب': students.length,
      };

      final directory = await getExternalStorageDirectory() ?? 
                        await getApplicationDocumentsDirectory();
      
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = 'all_students_$timestamp.json';
      final filePath = '${directory.path}/$fileName';

      final file = File(filePath);
      await file.writeAsString(
        const JsonEncoder.withIndent('  ').convert(data),
        encoding: utf8,
      );

      return ExportResult.success(filePath);

    } catch (e) {
      return ExportResult.error('فشل التصدير: $e');
    }
  }
}

/// نتيجة التصدير
class ExportResult {
  final bool success;
  final String? filePath;
  final String? errorMessage;

  ExportResult._({
    required this.success,
    this.filePath,
    this.errorMessage,
  });

  factory ExportResult.success(String path) {
    return ExportResult._(success: true, filePath: path);
  }

  factory ExportResult.error(String message) {
    return ExportResult._(success: false, errorMessage: message);
  }
}
